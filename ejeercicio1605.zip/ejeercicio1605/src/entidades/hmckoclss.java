/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author RPR-C80A404ES
 */
public class hmckoclss {
    
   private int id_accesorios;
   private int id_balones;
   private int id_calz;
   private int id_hom;
   private int id_kids;
   private int id_muj;
   private int id_ofer;

    public int getId_accesorios() {
        return id_accesorios;
    }

    public void setId_accesorios(int id_accesorios) {
        this.id_accesorios = id_accesorios;
    }

    public int getId_balones() {
        return id_balones;
    }

    public void setId_balones(int id_balones) {
        this.id_balones = id_balones;
    }

    public int getId_calz() {
        return id_calz;
    }

    public void setId_calz(int id_calz) {
        this.id_calz = id_calz;
    }

    public int getId_hom() {
        return id_hom;
    }

    public void setId_hom(int id_hom) {
        this.id_hom = id_hom;
    }

    public int getId_kids() {
        return id_kids;
    }

    public void setId_kids(int id_kids) {
        this.id_kids = id_kids;
    }

    public int getId_muj() {
        return id_muj;
    }

    public void setId_muj(int id_muj) {
        this.id_muj = id_muj;
    }

    public int getId_ofer() {
        return id_ofer;
    }

    public void setId_ofer(int id_ofer) {
        this.id_ofer = id_ofer;
    }

    public hmckoclss(int id_accesorios, int id_balones, int id_calz, int id_hom, int id_kids, int id_muj, int id_ofer) {
        this.id_accesorios = id_accesorios;
        this.id_balones = id_balones;
        this.id_calz = id_calz;
        this.id_hom = id_hom;
        this.id_kids = id_kids;
        this.id_muj = id_muj;
        this.id_ofer = id_ofer;
    }

    
    public String mostrarTab() {
        return "hmckoclss{" + "id_accesorios=" + id_accesorios + ", id_balones=" + id_balones + ", id_calz=" + id_calz + ", id_hom=" + id_hom + ", id_kids=" + id_kids + ", id_muj=" + id_muj + ", id_ofer=" + id_ofer + '}';
    }

    
}
