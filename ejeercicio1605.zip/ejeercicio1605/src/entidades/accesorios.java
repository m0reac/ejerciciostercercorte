/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author Usuario
 */
public class accesorios {
    private String producto;
    private int ref_producto;
    private String sexo;
    private String marca;
    private int id_accesorios;

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public int getRef_producto() {
        return ref_producto;
    }

    public void setRef_producto(int ref_producto) {
        this.ref_producto = ref_producto;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getId_accesorios() {
        return id_accesorios;
    }

    public void setId_accesorios(int id_accesorios) {
        this.id_accesorios = id_accesorios;
    }

    public accesorios(String producto, int ref_producto, String sexo, String marca, int id_accesorios) {
        this.producto = producto;
        this.ref_producto = ref_producto;
        this.sexo = sexo;
        this.marca = marca;
        this.id_accesorios = id_accesorios;
    }

    
    public String mostrarTab() {
        return "accesorios{" + "producto=" + producto + ", ref_producto=" + ref_producto + ", sexo=" + sexo + ", marca=" + marca + ", id_accesorios=" + id_accesorios + '}';
    }

   
   
}
