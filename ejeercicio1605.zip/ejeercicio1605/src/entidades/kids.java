/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author RPR-C80A404ES
 */
public class kids {
    
    private String prenda;
    private String talla;
    private String color;
    private int ref_prenda;
    private String sexo;
    private int id_kids;

    public String getPrenda() {
        return prenda;
    }

    public void setPrenda(String prenda) {
        this.prenda = prenda;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getRef_prenda() {
        return ref_prenda;
    }

    public void setRef_prenda(int ref_prenda) {
        this.ref_prenda = ref_prenda;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getId_kids() {
        return id_kids;
    }

    public void setId_kids(int id_kids) {
        this.id_kids = id_kids;
    }

    public kids(String prenda, String talla, String color, int ref_prenda, String sexo, int id_kids) {
        this.prenda = prenda;
        this.talla = talla;
        this.color = color;
        this.ref_prenda = ref_prenda;
        this.sexo = sexo;
        this.id_kids = id_kids;
    }

    
    public String mostrarTab() {
        return "kids{" + "prenda=" + prenda + ", talla=" + talla + ", color=" + color + ", ref_prenda=" + ref_prenda + ", sexo=" + sexo + ", id_kids=" + id_kids + '}';
    }

   
}
