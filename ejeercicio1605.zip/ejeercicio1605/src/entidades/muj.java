/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author RPR-C80A404ES
 */
public class muj {
    
private String talla;
private String prenda; 
private String color; 
private int ref_prenda;
private String marca;
private int id_muj;

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getPrenda() {
        return prenda;
    }

    public void setPrenda(String prenda) {
        this.prenda = prenda;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getRef_prenda() {
        return ref_prenda;
    }

    public void setRef_prenda(int ref_prenda) {
        this.ref_prenda = ref_prenda;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getId_muj() {
        return id_muj;
    }

    public void setId_muj(int id_muj) {
        this.id_muj = id_muj;
    }

    public muj(String talla, String prenda, String color, int ref_prenda, String marca, int id_muj) {
        this.talla = talla;
        this.prenda = prenda;
        this.color = color;
        this.ref_prenda = ref_prenda;
        this.marca = marca;
        this.id_muj = id_muj;
    }

    
    public String mostratTab() {
        return "muj{" + "talla=" + talla + ", prenda=" + prenda + ", color=" + color + ", ref_prenda=" + ref_prenda + ", marca=" + marca + ", id_muj=" + id_muj + '}';
    }

    
}
