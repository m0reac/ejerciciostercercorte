/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author RPR-C80A404ES
 */
public class hom {
    
     private String prenda;
    private String talla;
    private String color; 
    private int ref_prenda;
    private String marca;
    private int id_hom;

    public String getPrenda() {
        return prenda;
    }

    public void setPrenda(String prenda) {
        this.prenda = prenda;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getRef_prenda() {
        return ref_prenda;
    }

    public void setRef_prenda(int ref_prenda) {
        this.ref_prenda = ref_prenda;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getId_hom() {
        return id_hom;
    }

    public void setId_hom(int id_hom) {
        this.id_hom = id_hom;
    }

    public hom(String prenda, String talla, String color, int ref_prenda, String marca, int id_hom) {
        this.prenda = prenda;
        this.talla = talla;
        this.color = color;
        this.ref_prenda = ref_prenda;
        this.marca = marca;
        this.id_hom = id_hom;
    }

    
    public String mostrarTab() {
        return "hom{" + "prenda=" + prenda + ", talla=" + talla + ", color=" + color + ", ref_prenda=" + ref_prenda + ", marca=" + marca + ", id_hom=" + id_hom + '}';
    }

}
