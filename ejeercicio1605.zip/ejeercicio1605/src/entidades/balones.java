/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author Usuario
 */
public class balones {
    private String deporte;
    private int tamaño;
    private String material;
    private String modelo;
    private int id_balones;

    public String getDeporte() {
        return deporte;
    }

    public void setDeporte(String deporte) {
        this.deporte = deporte;
    }

    public int getTamaño() {
        return tamaño;
    }

    public void setTamaño(int tamaño) {
        this.tamaño = tamaño;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getId_balones() {
        return id_balones;
    }

    public void setId_balones(int id_balones) {
        this.id_balones = id_balones;
    }

    public balones(String deporte, int tamaño, String material, String modelo, int id_balones) {
        this.deporte = deporte;
        this.tamaño = tamaño;
        this.material = material;
        this.modelo = modelo;
        this.id_balones = id_balones;
    }

    
    public String mostrarTab() {
        return "balones{" + "deporte=" + deporte + ", tama\u00f1o=" + tamaño + ", material=" + material + ", modelo=" + modelo + ", id_balones=" + id_balones + '}';
    }

   
            
}
