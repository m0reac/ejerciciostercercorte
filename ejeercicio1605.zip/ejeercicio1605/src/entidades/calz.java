/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author RPR-C80A404ES
 */
public class calz {
    
   private String talla; 
   private String modelo;
   private String marca;
   private String color;
   private int ref_calz;
   private int id_balones;

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getRef_calz() {
        return ref_calz;
    }

    public void setRef_calz(int ref_calz) {
        this.ref_calz = ref_calz;
    }

    public int getId_balones() {
        return id_balones;
    }

    public void setId_balones(int id_balones) {
        this.id_balones = id_balones;
    }

    public calz(String talla, String modelo, String marca, String color, int ref_calz, int id_balones) {
        this.talla = talla;
        this.modelo = modelo;
        this.marca = marca;
        this.color = color;
        this.ref_calz = ref_calz;
        this.id_balones = id_balones;
    }

    
    public String mostrarTab() {
        return "calz{" + "talla=" + talla + ", modelo=" + modelo + ", marca=" + marca + ", color=" + color + ", ref_calz=" + ref_calz + ", id_balones=" + id_balones + '}';
    }

   
    
    
}
