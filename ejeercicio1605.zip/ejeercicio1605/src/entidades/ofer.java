/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author RPR-C80A404ES
 */
public class ofer {
    
    private String prenda;
    private String balon;
    private String accesorio;
    private int ref_prenda;
    private String marca;
    private String talla;
    private String sexo;
    private int ref_balon;
    private int ref_accesorio;
    private String color;
    private int id_ofer;

    public String getPrenda() {
        return prenda;
    }

    public void setPrenda(String prenda) {
        this.prenda = prenda;
    }

    public String getBalon() {
        return balon;
    }

    public void setBalon(String balon) {
        this.balon = balon;
    }

    public String getAccesorio() {
        return accesorio;
    }

    public void setAccesorio(String accesorio) {
        this.accesorio = accesorio;
    }

    public int getRef_prenda() {
        return ref_prenda;
    }

    public void setRef_prenda(int ref_prenda) {
        this.ref_prenda = ref_prenda;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public int getRef_balon() {
        return ref_balon;
    }

    public void setRef_balon(int ref_balon) {
        this.ref_balon = ref_balon;
    }

    public int getRef_accesorio() {
        return ref_accesorio;
    }

    public void setRef_accesorio(int ref_accesorio) {
        this.ref_accesorio = ref_accesorio;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getId_ofer() {
        return id_ofer;
    }

    public void setId_ofer(int id_ofer) {
        this.id_ofer = id_ofer;
    }

    public ofer(String prenda, String balon, String accesorio, int ref_prenda, String marca, String talla, String sexo, int ref_balon, int ref_accesorio, String color, int id_ofer) {
        this.prenda = prenda;
        this.balon = balon;
        this.accesorio = accesorio;
        this.ref_prenda = ref_prenda;
        this.marca = marca;
        this.talla = talla;
        this.sexo = sexo;
        this.ref_balon = ref_balon;
        this.ref_accesorio = ref_accesorio;
        this.color = color;
        this.id_ofer = id_ofer;
    }

   
    public String mostrarTab() {
        return "ofer{" + "prenda=" + prenda + ", balon=" + balon + ", accesorio=" + accesorio + ", ref_prenda=" + ref_prenda + ", marca=" + marca + ", talla=" + talla + ", sexo=" + sexo + ", ref_balon=" + ref_balon + ", ref_accesorio=" + ref_accesorio + ", color=" + color + ", id_ofer=" + id_ofer + '}';
    }

    
}
